package details;

import java.util.Calendar;
import java.util.Date;
import java.util.Vector;
import java.util.TimeZone;
import java.text.SimpleDateFormat;

public class  CalendarDate{
		
   
	public static String main() {

		Date date = new Date();  
		//getting local time, date, day of week and other details in local timezone
        Calendar localCalendar = Calendar.getInstance(TimeZone.getDefault());
		 SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");  
	    String today= formatter.format(date); 

		
		System.out.println("Current Day " + today);

		    	
	return today;
		
    }

    public static void main(String args[]) {
		main();
	}

}
